/* ═══════════════════════════════════════════════════════════
   POST · Physics
   ═══════════════════════════════════════════════════════════ */

registerPost({
  mode:     'physics',
  title:    "The Schrödinger Equation — Quantum Mechanics in Full",
  category: 'quantum',
  date:     '17 May 2026',
  body: `
The time-dependent Schrödinger equation is the central equation of non-relativistic
quantum mechanics. It describes how the quantum state $|\psi\rangle$ of a system
evolves in time:

$$i\hbar\frac{\partial}{\partial t}|\psi\rangle = \hat{H}|\psi\rangle$$

Here $\hbar$ is the reduced Planck constant and $\hat{H}$ is the Hamiltonian operator,
which encodes the total energy of the system.

For a single non-relativistic particle of mass $m$ in a potential $V(\mathbf{r}, t)$,
the equation takes the explicit form:

$$i\hbar\frac{\partial\psi}{\partial t} = \left[-\frac{\hbar^2}{2m}\nabla^2 + V(\mathbf{r},t)\right]\psi$$

When the potential is time-independent, we can separate variables. Writing
$\psi(\mathbf{r}, t) = \phi(\mathbf{r})\,e^{-iEt/\hbar}$ leads to the
time-independent Schrödinger equation:

$$\hat{H}\phi = E\phi$$

This is an eigenvalue problem — the allowed energies $E$ are the eigenvalues of
$\hat{H}$, and the corresponding $\phi$ are the stationary states. The hydrogen
atom's discrete spectral lines follow directly from solving this equation with a
Coulomb potential $V = -e^2/4\pi\varepsilon_0 r$.
  `
});
