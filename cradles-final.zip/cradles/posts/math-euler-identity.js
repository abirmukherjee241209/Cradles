/* ═══════════════════════════════════════════════════════════
   POST · Mathematics
   ═══════════════════════════════════════════════════════════
   mode      : 'math' or 'physics'
   title     : string
   category  : 'calculus' | 'algebra' | 'trig' | 'linalg' | 'analysis'
               (for physics: 'classical' | 'em' | 'thermo' | 'quantum' | 'relativity')
   date      : string, displayed as-is
   body      : template literal — plain prose + LaTeX fully supported.
               Inline math  →  $...$
               Display math →  $$...$$
               Blank lines between paragraphs become paragraph breaks.
   ═══════════════════════════════════════════════════════════ */

registerPost({
  mode:     'math',
  title:    "Euler's Identity — The Most Beautiful Equation",
  category: 'analysis',
  date:     '17 May 2026',
  body: `
Euler's identity is routinely voted the most beautiful result in all of mathematics.
It fuses five fundamental constants into a single, breathtaking expression:

$$e^{i\pi} + 1 = 0$$

At first glance this seems miraculous. $e \approx 2.718$ is the base of natural logarithms,
$i = \sqrt{-1}$ is the imaginary unit, and $\pi \approx 3.14159$ is the ratio of a circle's
circumference to its diameter. That three such unrelated quantities conspire to produce
exactly $-1$ is not a coincidence — it is a direct consequence of Euler's formula:

$$e^{i\theta} = \cos\theta + i\sin\theta$$

Setting $\theta = \pi$ gives $e^{i\pi} = \cos\pi + i\sin\pi = -1 + 0 = -1$,
and the identity follows immediately.

The deeper insight is geometric. Multiplication by $e^{i\theta}$ in the complex plane
is a rotation by angle $\theta$. Rotating by $\pi$ radians flips a point to its
antipode — so $e^{i\pi}$ maps $1$ to $-1$. The identity is simply the algebraic
statement of a half-turn.
  `
});
